package com.genspark.springbootstudentmanagement.service;

import com.genspark.springbootstudentmanagement.dao.StudentDao;
import com.genspark.springbootstudentmanagement.entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentDao students;

    @Override
    public List<Student> getAllStudents() {

        return students.findAll();
    }

    @Override
    public Student getStudent(int id) {
        return students.getReferenceById(id);
    }

    @Override
    public Student updateStudent(Student s) {
        if (students.findByStudentId(s.getStudentId()) == 1) {
            return students.save(s);
        }
        return null;
    }

    @Override
    public Student addStudent(Student s) {
        return students.save(s);
    }

    @Override
    public String deleteStudent(int id) {
        String resp = "Student does not exist.";

        if (students.findByStudentId(id) == 1) {
            students.deleteById(id);
            resp = "Student with id: " + id + " has been deleted.";
        }
        return resp;
    }
}
