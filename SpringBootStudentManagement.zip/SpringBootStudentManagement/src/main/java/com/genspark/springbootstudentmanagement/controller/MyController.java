package com.genspark.springbootstudentmanagement.controller;

import com.genspark.springbootstudentmanagement.entity.Student;
import com.genspark.springbootstudentmanagement.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MyController {

    @Autowired
    private StudentService ss;

    @GetMapping("/home")
    public String home(@RequestParam(value= "name", defaultValue = "Hello world")
                           String name, @RequestParam(value= "msg",
                           defaultValue = "good morning") String msg){
            return "<html><body><h1>Welcome to Student Registration" +
                    "</body></html";
    }

    @GetMapping("/students")
    public List<Student> getStudents(){
        return ss.getAllStudents();
    }

    @GetMapping("/students/{studentid}")
    public Student getStudent(@PathVariable String studentid){
        return ss.getStudent(Integer.parseInt(studentid));
    }

    @PostMapping("/students")
    public Student addStudent(@RequestBody Student s){
        return ss.addStudent(s);
    }

    @PutMapping("/students")
    public Student updateCourse(@RequestBody Student s){
        return ss.updateStudent(s);
    }

    @DeleteMapping("/students/{studentid}")
    public String deleteStudents(@PathVariable String studentid){

        return  ss.deleteStudent(Integer.parseInt(studentid));
    }
}
