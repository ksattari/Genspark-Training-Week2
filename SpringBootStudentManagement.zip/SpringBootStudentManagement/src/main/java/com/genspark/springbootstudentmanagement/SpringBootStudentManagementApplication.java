package com.genspark.springbootstudentmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootStudentManagementApplication {


	public static void main(String[] args) {
		SpringApplication.run(SpringBootStudentManagementApplication.class, args);
	}

}
