package com.genspark.springbootstudentmanagement.entity;

import jakarta.persistence.*;

import java.util.Set;

@Entity
@Table(name="students")
public class Student {

    @Id
    @Column(name="student_id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int studentId;
    private String studentName;
    private String address;

    public Student(){}

    public Student(String studentName, String address) {
        this.studentName = studentName;
        this.address = address;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setAddress(String address){
        this.address = address;
    }

    public String getAddress() {
        return address;
    }
}
