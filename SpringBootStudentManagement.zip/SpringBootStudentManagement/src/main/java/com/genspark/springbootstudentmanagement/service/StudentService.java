package com.genspark.springbootstudentmanagement.service;

import com.genspark.springbootstudentmanagement.entity.Student;
import java.util.List;

public interface StudentService {
    List<Student> getAllStudents();
    Student getStudent(int id);
    Student addStudent(Student c);
    Student updateStudent(Student c);
    String deleteStudent(int id);

}
