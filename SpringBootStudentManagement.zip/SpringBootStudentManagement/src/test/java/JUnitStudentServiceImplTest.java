import com.genspark.springbootstudentmanagement.dao.StudentDao;
import com.genspark.springbootstudentmanagement.entity.Student;
import com.genspark.springbootstudentmanagement.service.StudentServiceImpl;
import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.event.annotation.BeforeTestClass;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mock.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

public class JUnitStudentServiceImplTest {


        static StudentDao dao = mock(StudentDao.class);
        static StudentServiceImpl ss;

        @BeforeAll
        static void setup(){
            ss = new StudentServiceImpl((dao));
        }
        @Test
        void testUpdateStudent(){

            Student s = new Student();

            when(dao.save(s)).thenReturn(s);
            when(dao.findByStudentId(s.getStudentId())).thenReturn(1);
            assertEquals(s,ss.updateStudent(s));
        }

}
